
from agents.base_agent import BaseAgent
from pyspark.sql import functions as F

class DefectValidationAgent(BaseAgent):
    def __init__(self):
        super().__init__("DefectValidationAgent")

    def execute(self, input_table: str, output_table: str):
        df = spark.table(input_table)

        validated_df = (
            df.withColumn("is_valid", 
                F.when(
                    F.col("fields.description").isNotNull() &
                    F.col("fields.summary").isNotNull(), True
                ).otherwise(False)
            )
        )

        validated_df.write.format("delta").mode("overwrite").saveAsTable(output_table)
        self.logger.info(f"Validated defects written to: {output_table}")
