from graph_agent import build_graph, build_prompt

task = "Get average transaction amount by customer"
schema = """
customer_id: string
transaction_id: string
amount: double
timestamp: timestamp
"""
source = "Delta table at path `/mnt/data/transactions`"

graph = build_graph()

initial_state = {
    "prompt": build_prompt(task, schema, source),
    "code": None,
    "valid": None,
    "error": None,
    "output": None,
    "summary": None
}

final_state = graph.invoke(initial_state)

print("Generated Code:\n", final_state["code"])
print("Output:\n", final_state["output"])
print("Summary:\n", final_state["summary"])