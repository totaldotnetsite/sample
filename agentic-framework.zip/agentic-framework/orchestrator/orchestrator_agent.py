
import json
import importlib
import logging

class OrchestratorAgent:
    def __init__(self, execution_plan):
        self.execution_plan = execution_plan
        self.logger = logging.getLogger("OrchestratorAgent")

    def load_agent(self, agent_path: str):
        module_path, class_name = agent_path.rsplit('.', 1)
        module = importlib.import_module(module_path)
        agent_class = getattr(module, class_name)
        return agent_class

    def run(self):
        for step in self.execution_plan:
            try:
                agent_name = step["name"]
                agent_path = step["path"]
                params = step.get("params", {})

                self.logger.info(f"Starting agent: {agent_name}")
                agent_class = self.load_agent(agent_path)
                agent_instance = agent_class(**params.get("init", {}))
                result = agent_instance.run(**params.get("run", {}))
                self.logger.info(f"Agent {agent_name} finished.
")
            except Exception as e:
                self.logger.error(f"Agent {agent_name} failed: {e}")
                raise
