import requests
import os

DATABRICKS_TOKEN = os.getenv("DATABRICKS_TOKEN")
LLAMA4_ENDPOINT_URL = "https://<your-workspace>.databricks.azure.net/serving-endpoints/llama4/completions"

def call_llama(prompt):
    headers = {
        "Authorization": f"Bearer {DATABRICKS_TOKEN}",
        "Content-Type": "application/json"
    }
    payload = {
        "messages": [
            {"role": "system", "content": "You are a helpful Databricks code generator."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.2,
        "max_tokens": 1024
    }
    response = requests.post(LLAMA4_ENDPOINT_URL, headers=headers, json=payload)
    response.raise_for_status()
    return response.json()["choices"][0]["message"]["content"]