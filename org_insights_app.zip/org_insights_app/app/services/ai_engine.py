
from transformers import pipeline

qa_pipeline = pipeline("text2text-generation", model="mistralai/Mistral-7B-Instruct-v0.3")

def interpret_question(question: str) -> dict:
    prompt = f"""
    Interpret the following business question and extract:
    1. Intent (performance, efficiency, quality, etc)
    2. Filters (team, date range, etc)

    Question: "{question}"
    Output as JSON.
    """
    response = qa_pipeline(prompt, max_new_tokens=100)[0]['generated_text']
    try:
        return eval(response)
    except:
        return {"intent": "unknown", "filters": {}}
