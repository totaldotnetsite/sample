
from orchestrator.orchestrator_agent import OrchestratorAgent

execution_plan = []  # Define your execution steps here

orchestrator = OrchestratorAgent(execution_plan)
orchestrator.run()
