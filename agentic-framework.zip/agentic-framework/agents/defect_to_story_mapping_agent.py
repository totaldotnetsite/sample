
from agents.base_agent import BaseAgent
import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

class DefectToStoryMappingAgent(BaseAgent):
    def __init__(self):
        super().__init__("DefectToStoryMappingAgent")

    def execute(self, defect_embeddings_table: str, story_embeddings_table: str, output_table: str, top_n: int = 3):
        defects = spark.table(defect_embeddings_table).toPandas()
        stories = spark.table(story_embeddings_table).toPandas()

        defect_vecs = np.stack(defects["embedding"].values)
        story_vecs = np.stack(stories["embedding"].values)

        similarity = cosine_similarity(defect_vecs, story_vecs)

        mappings = []
        for i, defect_row in defects.iterrows():
            top_indices = similarity[i].argsort()[-top_n:][::-1]
            for j in top_indices:
                mappings.append({
                    "defect_id": defect_row["id"],
                    "story_id": stories.iloc[j]["id"],
                    "score": similarity[i][j]
                })

        result_df = pd.DataFrame(mappings)
        spark_df = spark.createDataFrame(result_df)
        spark_df.write.format("delta").mode("overwrite").saveAsTable(output_table)
        self.logger.info(f"Defect-story mappings written to: {output_table}")
