from langgraph.graph import StateGraph, END
from typing import TypedDict, Optional
from llama_client import call_llama
import io, contextlib

class AgentState(TypedDict):
    prompt: str
    code: Optional[str]
    valid: Optional[bool]
    error: Optional[str]
    output: Optional[str]
    summary: Optional[str]

def build_prompt(task: str, schema: str, source: str) -> str:
    return f"""
Task: {task}
Data Schema:
{schema}
Data Source:
{source}
Instructions:
Generate complete PySpark code using Delta tables.
Return only code.
"""

def generate_code(state: AgentState) -> AgentState:
    code = call_llama(state["prompt"])
    return {**state, "code": code}

def validate_code(state: AgentState) -> AgentState:
    try:
        exec(state["code"], globals())
        return {**state, "valid": True, "error": None}
    except Exception as e:
        return {**state, "valid": False, "error": str(e)}

def regenerate_code(state: AgentState) -> AgentState:
    feedback_prompt = state["prompt"] + f"\n\nFix the following error:\n{state['error']}"
    code = call_llama(feedback_prompt)
    return {**state, "code": code}

def execute_code(state: AgentState) -> AgentState:
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        exec(state["code"], globals())
    return {**state, "output": buffer.getvalue()}

def summarize_output(state: AgentState) -> AgentState:
    lines = state["output"].splitlines()
    summary = f"Output has {len(lines)} lines.\nSample:\n" + "\n".join(lines[:2])
    return {**state, "summary": summary}

def build_graph():
    builder = StateGraph(AgentState)
    builder.add_node("generate_code", generate_code)
    builder.add_node("validate_code", validate_code)
    builder.add_node("regenerate_code", regenerate_code)
    builder.add_node("execute_code", execute_code)
    builder.add_node("summarize_output", summarize_output)
    builder.add_node("end", lambda state: state)

    builder.set_entry_point("generate_code")
    builder.add_edge("generate_code", "validate_code")

    def check_valid(state: AgentState):
        return "execute_code" if state["valid"] else "regenerate_code"

    builder.add_conditional_edges("validate_code", check_valid)
    builder.add_edge("regenerate_code", "validate_code")
    builder.add_edge("execute_code", "summarize_output")
    builder.add_edge("summarize_output", "end")

    return builder.compile()