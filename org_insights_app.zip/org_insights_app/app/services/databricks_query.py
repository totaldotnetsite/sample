
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, avg

spark = SparkSession.builder.getOrCreate()

def query_databricks(intent: str, filters: dict) -> dict:
    team = filters.get("team")
    time_range = filters.get("time_range")

    df = spark.table("analytics.performance_metrics")

    if team:
        df = df.filter(col("team_name") == team)
    if time_range:
        df = apply_time_filter(df, time_range)

    metric_map = {
        "efficiency": "efficiency_score",
        "productivity": "tasks_completed",
        "quality": "defect_rate",
        "performance": "overall_score"
    }
    metric_col = metric_map.get(intent, "overall_score")

    monthly_df = df.groupBy("month").agg(avg(metric_col).alias("value")).orderBy("month")
    pd_df = monthly_df.toPandas()

    return {
        "summary": f"{intent.title()} for Team {team or 'All'} during {time_range or 'latest'}",
        "chart_data": {
            "labels": pd_df["month"].tolist(),
            "values": pd_df["value"].round(2).tolist(),
            "label": f"{intent.title()}",
            "title": f"{intent.title()} over time"
        }
    }

def apply_time_filter(df, time_range: str):
    if time_range == "Q1 2024":
        return df.filter(col("month").isin(["2024-01", "2024-02", "2024-03"]))
    return df
