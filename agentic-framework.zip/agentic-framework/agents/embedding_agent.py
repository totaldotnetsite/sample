
from agents.base_agent import BaseAgent
from sentence_transformers import SentenceTransformer
import pandas as pd

class EmbeddingAgent(BaseAgent):
    def __init__(self, model_name="all-MiniLM-L6-v2"):
        super().__init__("EmbeddingAgent")
        self.model = SentenceTransformer(model_name)

    def execute(self, input_table: str, text_column: str, id_column: str, output_table: str):
        df = spark.table(input_table).select(id_column, text_column).toPandas()

        embeddings = self.model.encode(df[text_column].tolist(), show_progress_bar=True)
        df["embedding"] = embeddings.tolist()

        spark_df = spark.createDataFrame(df)
        spark_df.write.format("delta").mode("overwrite").saveAsTable(output_table)
        self.logger.info(f"Embeddings written to: {output_table}")
