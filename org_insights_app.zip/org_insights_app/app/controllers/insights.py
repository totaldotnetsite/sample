
from app.services.databricks_query import query_databricks
from app.services.ai_engine import interpret_question

def process_query(question):
    parsed = interpret_question(question)
    raw_data = query_databricks(parsed['intent'], parsed['filters'])

    return raw_data
