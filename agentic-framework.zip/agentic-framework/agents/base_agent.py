
import logging
from abc import ABC, abstractmethod

class BaseAgent(ABC):
    def __init__(self, agent_name: str):
        self.agent_name = agent_name
        self.logger = logging.getLogger(agent_name)
        self.logger.setLevel(logging.INFO)

    def run(self, **kwargs):
        self.logger.info(f"Agent {self.agent_name} started.")
        result = self.execute(**kwargs)
        self.logger.info(f"Agent {self.agent_name} completed.")
        return result

    @abstractmethod
    def execute(self, **kwargs):
        pass
