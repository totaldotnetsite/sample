// Initialize all components when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeCharts();
    initializeTransactions();
    setupEventListeners();
    updateDashboardData();
});

// Initialize spending charts
function initializeCharts() {
    initializeSpendingChart();
    initializeCreditUsageChart();
}

function initializeSpendingChart() {
    const spendingCtx = document.getElementById('spendingChart');
    if (!spendingCtx) return;

    const categoryColors = {
        'Shopping': {
            background: '#3b82f6',
            border: '#2563eb'
        },
        'Dining': {
            background: '#10b981',
            border: '#059669'
        },
        'Entertainment': {
            background: '#f59e0b',
            border: '#d97706'
        },
        'Travel': {
            background: '#8b5cf6',
            border: '#7c3aed'
        },
        'Others': {
            background: '#6b7280',
            border: '#4b5563'
        }
    };

    const monthlyData = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
            {
                label: 'Shopping',
                data: [450, 650, 300, 500, 800, 400],
                backgroundColor: categoryColors.Shopping.background,
                borderColor: categoryColors.Shopping.border,
                borderWidth: 1,
                borderRadius: 4,
                stack: 'stack0'
            },
            {
                label: 'Dining',
                data: [250, 400, 200, 350, 450, 300],
                backgroundColor: categoryColors.Dining.background,
                borderColor: categoryColors.Dining.border,
                borderWidth: 1,
                borderRadius: 4,
                stack: 'stack0'
            },
            {
                label: 'Entertainment',
                data: [200, 350, 150, 300, 400, 350],
                backgroundColor: categoryColors.Entertainment.background,
                borderColor: categoryColors.Entertainment.border,
                borderWidth: 1,
                borderRadius: 4,
                stack: 'stack0'
            },
            {
                label: 'Travel',
                data: [150, 300, 50, 250, 200, 300],
                backgroundColor: categoryColors.Travel.background,
                borderColor: categoryColors.Travel.border,
                borderWidth: 1,
                borderRadius: 4,
                stack: 'stack0'
            },
            {
                label: 'Others',
                data: [150, 200, 100, 200, 150, 150],
                backgroundColor: categoryColors.Others.background,
                borderColor: categoryColors.Others.border,
                borderWidth: 1,
                borderRadius: 4,
                stack: 'stack0'
            }
        ]
    };

    new Chart(spendingCtx, {
        type: 'bar',
        data: monthlyData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        usePointStyle: true,
                        padding: 20,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    backgroundColor: '#0f172a',
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    padding: 12,
                    displayColors: true,
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: $${context.raw.toLocaleString()}`;
                        },
                        footer: function(tooltipItems) {
                            const total = tooltipItems.reduce((sum, item) => sum + item.raw, 0);
                            return `Total: $${total.toLocaleString()}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        padding: 10
                    },
                    border: {
                        display: false
                    }
                },
                y: {
                    stacked: true,
                    beginAtZero: true,
                    grid: {
                        color: '#e2e8f0',
                        drawBorder: false
                    },
                    ticks: {
                        padding: 10,
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    },
                    border: {
                        display: false
                    }
                }
            }
        }
    });
}

function initializeCreditUsageChart() {
    const creditUsageCtx = document.getElementById('creditUsageChart');
    if (!creditUsageCtx) return;

    const totalLimit = 5000;
    const usedCredit = 1234.56;
    const availableCredit = totalLimit - usedCredit;
    const percentage = (usedCredit / totalLimit) * 100;

    // Get status color based on percentage
    const getStatusColor = (pct) => {
        if (pct >= 75) return { color: '#ef4444', text: 'High Usage' };
        if (pct >= 50) return { color: '#f59e0b', text: 'Moderate Usage' };
        return { color: '#22c55e', text: 'Good Standing' };
    };

    const statusInfo = getStatusColor(percentage);

    // Create gradient for used credit
    const ctx = creditUsageCtx.getContext('2d');
    const gradientUsed = ctx.createLinearGradient(0, 0, 0, 200);
    gradientUsed.addColorStop(0, statusInfo.color);
    gradientUsed.addColorStop(1, `${statusInfo.color}80`);

    const chart = new Chart(creditUsageCtx, {
        type: 'doughnut',
        data: {
            labels: ['Used', 'Available'],
            datasets: [{
                data: [usedCredit, availableCredit],
                backgroundColor: [gradientUsed, '#e2e8f0'],
                borderWidth: 0,
                cutout: '75%',
                borderRadius: 20,
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: 20
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    enabled: true,
                    callbacks: {
                        label: function(context) {
                            const value = context.raw;
                            const total = context.dataset.data.reduce((a, b) => a + b);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${context.label}: $${value.toLocaleString()} (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateScale: true,
                animateRotate: true,
                duration: 1000,
                onComplete: function(animation) {
                    updateCreditUsageStats(usedCredit, availableCredit, percentage, statusInfo);
                }
            }
        }
    });

    // Add click handlers for the chart segments
    creditUsageCtx.onclick = function(evt) {
        const points = chart.getElementsAtEventForMode(evt, 'nearest', { intersect: true }, true);
        if (points.length) {
            const segment = points[0];
            const value = chart.data.datasets[0].data[segment.index];
            const label = chart.data.labels[segment.index];
            
            // Show detailed breakdown
            showCreditBreakdown(label, value, percentage, statusInfo);
        }
    };

    // Initialize historical usage toggle
    const historicalToggle = document.getElementById('showHistoricalUsage');
    if (historicalToggle) {
        historicalToggle.addEventListener('change', function() {
            const historicalChart = document.getElementById('historicalUsageChart');
            if (this.checked && historicalChart) {
                historicalChart.classList.remove('d-none');
                initializeHistoricalUsageChart();
            } else if (historicalChart) {
                historicalChart.classList.add('d-none');
            }
        });
    }
}

function updateCreditUsageStats(used, available, percentage, statusInfo) {
    // Update the stats in the UI
    const elements = {
        used: document.getElementById('creditUsed'),
        available: document.getElementById('creditAvailable'),
        percentage: document.getElementById('creditPercentage'),
        status: document.querySelector('.credit-status .badge'),
        limit: document.getElementById('creditLimit')
    };

    if (elements.used) elements.used.textContent = `$${used.toLocaleString()}`;
    if (elements.available) elements.available.textContent = `$${available.toLocaleString()}`;
    if (elements.percentage) elements.percentage.textContent = `${percentage.toFixed(1)}%`;
    if (elements.limit) elements.limit.textContent = `$${(used + available).toLocaleString()}`;
    
    if (elements.status) {
        elements.status.className = `badge bg-${percentage >= 75 ? 'danger' : percentage >= 50 ? 'warning' : 'success'}`;
        elements.status.textContent = statusInfo.text;
    }

    // Update progress bar if exists
    const progressBar = document.querySelector('.credit-usage-progress .progress-bar');
    if (progressBar) {
        progressBar.style.width = `${percentage}%`;
        progressBar.style.backgroundColor = statusInfo.color;
    }
}

function showCreditBreakdown(label, value, percentage, statusInfo) {
    const modal = new bootstrap.Modal(document.getElementById('creditBreakdownModal'));
    const modalBody = document.querySelector('#creditBreakdownModal .modal-body');
    
    if (modalBody) {
        if (label === 'Used') {
            modalBody.innerHTML = `
                <div class="credit-breakdown">
                    <div class="breakdown-header">
                        <h3>Credit Usage Breakdown</h3>
                        <span class="badge bg-${percentage >= 75 ? 'danger' : percentage >= 50 ? 'warning' : 'success'}">${statusInfo.text}</span>
                    </div>
                    <div class="breakdown-stats">
                        <div class="row g-3">
                            <div class="col-6">
                                <div class="stat-card">
                                    <label>Current Balance</label>
                                    <h4>$${value.toLocaleString()}</h4>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="stat-card">
                                    <label>Usage Rate</label>
                                    <h4>${percentage.toFixed(1)}%</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="recent-charges mt-4">
                        <h4>Recent Charges</h4>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Description</th>
                                        <th class="text-end">Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Jan 30, 2025</td>
                                        <td>Amazon.com</td>
                                        <td class="text-end">$125.99</td>
                                    </tr>
                                    <tr>
                                        <td>Jan 29, 2025</td>
                                        <td>Whole Foods Market</td>
                                        <td class="text-end">$89.50</td>
                                    </tr>
                                    <tr>
                                        <td>Jan 28, 2025</td>
                                        <td>Netflix</td>
                                        <td class="text-end">$14.99</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            `;
        } else {
            modalBody.innerHTML = `
                <div class="credit-breakdown">
                    <div class="breakdown-header">
                        <h3>Available Credit Details</h3>
                    </div>
                    <div class="breakdown-stats">
                        <div class="row g-3">
                            <div class="col-6">
                                <div class="stat-card">
                                    <label>Available Credit</label>
                                    <h4>$${value.toLocaleString()}</h4>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="stat-card">
                                    <label>Available Percentage</label>
                                    <h4>${(100 - percentage).toFixed(1)}%</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="credit-tips mt-4">
                        <h4>Credit Health Tips</h4>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-check-circle text-success"></i> Keep utilization below 30% for optimal credit score</li>
                            <li><i class="fas fa-info-circle text-primary"></i> Consider requesting a credit limit increase</li>
                            <li><i class="fas fa-shield-alt text-warning"></i> Monitor your credit score regularly</li>
                        </ul>
                    </div>
                </div>
            `;
        }
        modal.show();
    }
}

function initializeHistoricalUsageChart() {
    const ctx = document.getElementById('historicalUsageChart');
    if (!ctx) return;

    const months = ['Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan'];
    const usageData = [35, 42, 28, 45, 32, 24.7];

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: months,
            datasets: [{
                label: 'Credit Usage %',
                data: usageData,
                borderColor: '#3b82f6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#ffffff',
                pointBorderColor: '#3b82f6',
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `Usage: ${context.raw}%`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            }
        }
    });
}

function setupEventListeners() {
    // Timeframe selector for spending chart
    const timeframeSelect = document.getElementById('timeframe');
    if (timeframeSelect) {
        timeframeSelect.addEventListener('change', function() {
            // This would typically fetch new data from an API
            const mockData = {
                'week': [300, 450, 280, 520, 600, 400, 350],
                'month': [1200, 1900, 800, 1600, 2000, 1500],
                'year': [12000, 15000, 18000, 14000, 16000, 19000, 17000, 20000, 18500, 22000, 19500, 21000]
            };
            
            // Update chart with new data
            const chart = Chart.getChart('spendingChart');
            if (chart) {
                chart.data.datasets[0].data = mockData[this.value];
                chart.data.labels = generateLabels(this.value);
                chart.update();
            }
        });
    }
}

function generateLabels(timeframe) {
    switch(timeframe) {
        case 'week':
            return ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        case 'month':
            return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
        case 'year':
            return ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        default:
            return [];
    }
}

function initializeTransactions() {
    // Add click event listeners to transaction items
    const transactionItems = document.querySelectorAll('.transaction-item');
    transactionItems.forEach(item => {
        item.addEventListener('click', function() {
            // Remove active class from all items
            transactionItems.forEach(i => i.classList.remove('active'));
            // Add active class to clicked item
            this.classList.add('active');
            // Load transaction details
            loadTransactionDetails(this.dataset.transactionId);
        });
    });

    // Initialize search functionality
    const searchInput = document.getElementById('searchTransactions');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            filterTransactions(this.value);
        });
    }

    // Initialize date filter
    const dateFilter = document.getElementById('transactionDate');
    if (dateFilter) {
        dateFilter.addEventListener('change', function() {
            filterTransactionsByDate(this.value);
        });
    }

    // Initialize category filter
    const categoryFilter = document.getElementById('transactionCategory');
    if (categoryFilter) {
        categoryFilter.addEventListener('change', function() {
            filterTransactionsByCategory(this.value);
        });
    }
}

function loadTransactionDetails(transactionId) {
    // This would typically fetch data from an API
    // For demo purposes, we'll use mock data
    const mockTransactions = {
        '1': {
            merchant: 'Amazon.com',
            logo: 'https://logo.clearbit.com/amazon.com',
            date: 'January 30, 2025',
            amount: '$125.99',
            category: 'Shopping',
            status: 'Completed',
            address: '410 Terry Ave N, Seattle, WA 98109, United States',
            phone: '(206) 266-1000',
            website: 'www.amazon.com',
            mapLocation: 'Amazon+Headquarters,Seattle+WA'
        },
        '2': {
            merchant: 'Whole Foods Market',
            logo: 'https://logo.clearbit.com/wholefoodsmarket.com',
            date: 'January 29, 2025',
            amount: '$89.50',
            category: 'Groceries',
            status: 'Completed',
            address: '550 Bowie St, Austin, TX 78703, United States',
            phone: '(512) 477-4455',
            website: 'www.wholefoodsmarket.com',
            mapLocation: 'Whole+Foods+Market,Austin+TX'
        },
        '3': {
            merchant: 'Netflix',
            logo: 'https://logo.clearbit.com/netflix.com',
            date: 'January 28, 2025',
            amount: '$14.99',
            category: 'Entertainment',
            status: 'Completed',
            address: '100 Winchester Cir, Los Gatos, CA 95032, United States',
            phone: '(408) 540-3700',
            website: 'www.netflix.com',
            mapLocation: 'Netflix+Headquarters,Los+Gatos+CA'
        }
    };

    const transaction = mockTransactions[transactionId];
    if (!transaction) return;

    // Update merchant header
    document.querySelector('.merchant-logo img').src = transaction.logo;
    document.querySelector('.merchant-logo img').alt = transaction.merchant;
    document.querySelector('.merchant-info h3').textContent = transaction.merchant;
    document.querySelector('.merchant-info .badge').textContent = transaction.category;

    // Update transaction details
    document.querySelector('.detail-item:nth-child(1) .detail-value').textContent = transaction.date;
    document.querySelector('.detail-item:nth-child(2) .detail-value').textContent = transaction.amount;
    document.querySelector('.detail-item:nth-child(3) .detail-value').textContent = transaction.category;
    document.querySelector('.detail-item:nth-child(4) .detail-value .badge').textContent = transaction.status;

    // Update merchant contact details
    const contactItems = document.querySelectorAll('.contact-item');
    contactItems[0].querySelector('span').textContent = transaction.address;
    contactItems[1].querySelector('span').textContent = transaction.phone;
    contactItems[2].querySelector('a').textContent = transaction.website;
    contactItems[2].querySelector('a').href = `https://${transaction.website}`;

    // Update map
    const mapContainer = document.querySelector('.map-container iframe');
    mapContainer.src = `https://www.google.com/maps/embed/v1/place?key=YOUR_API_KEY&q=${transaction.mapLocation}`;
}

function filterTransactions(searchTerm) {
    const items = document.querySelectorAll('.transaction-item');
    searchTerm = searchTerm.toLowerCase();

    items.forEach(item => {
        const merchant = item.querySelector('.transaction-merchant').textContent.toLowerCase();
        const amount = item.querySelector('.amount').textContent.toLowerCase();
        const date = item.querySelector('.transaction-date').textContent.toLowerCase();

        if (merchant.includes(searchTerm) || amount.includes(searchTerm) || date.includes(searchTerm)) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

function filterTransactionsByDate(date) {
    // This would typically filter based on the selected date
    // For demo purposes, we'll just log the selected date
    console.log('Filtering by date:', date);
}

function filterTransactionsByCategory(category) {
    const items = document.querySelectorAll('.transaction-item');
    
    items.forEach(item => {
        if (!category || category === '') {
            item.style.display = '';
            return;
        }

        const itemCategory = item.querySelector('.badge').textContent;
        item.style.display = itemCategory === category ? '' : 'none';
    });
}

// Load transaction data
function loadTransactions() {
    const transactions = [
        {
            date: '2025-01-30',
            merchant: 'Amazon',
            category: 'Shopping',
            amount: 125.99,
            status: 'Posted'
        },
        {
            date: '2025-01-29',
            merchant: 'Whole Foods',
            category: 'Groceries',
            amount: 89.50,
            status: 'Posted'
        },
        {
            date: '2025-01-28',
            merchant: 'Netflix',
            category: 'Entertainment',
            amount: 14.99,
            status: 'Posted'
        }
        // Add more transactions as needed
    ];

    const tbody = document.getElementById('transactionsList');
    tbody.innerHTML = transactions.map(t => `
        <tr>
            <td>${new Date(t.date).toLocaleDateString()}</td>
            <td>${t.merchant}</td>
            <td>${t.category}</td>
            <td>$${t.amount.toFixed(2)}</td>
            <td><span class="badge bg-success">${t.status}</span></td>
        </tr>
    `).join('');
}

// Update dashboard data
function updateDashboardData() {
    // This function would typically fetch real-time data from an API
    // For demo purposes, we're using static data
    const creditLimit = 6000;
    const currentBalance = 2450.75;
    const availableCredit = creditLimit - currentBalance;
    
    // Update progress bar
    const progressBar = document.querySelector('.progress-bar');
    if (progressBar) {
        const utilizationPercentage = (currentBalance / creditLimit) * 100;
        progressBar.style.width = `${utilizationPercentage}%`;
    }
}
