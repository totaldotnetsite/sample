
import requests
from agents.base_agent import BaseAgent

class JiraDownloadAgent(BaseAgent):
    def __init__(self, jira_url, auth_token):
        super().__init__("JiraDownloadAgent")
        self.jira_url = jira_url
        self.auth_token = auth_token

    def execute(self, project_key, jql_query):
        headers = {
            "Authorization": f"Bearer {self.auth_token}",
            "Content-Type": "application/json"
        }

        url = f"{self.jira_url}/rest/api/2/search"
        params = {
            "jql": f"project = {project_key} AND {jql_query}",
            "maxResults": 1000
        }

        self.logger.info(f"Querying Jira: {params['jql']}")
        response = requests.get(url, headers=headers, params=params)

        if response.status_code != 200:
            self.logger.error(f"Failed to fetch Jira data: {response.text}")
            raise Exception("Jira API Error")

        data = response.json()
        return data['issues']
