
from flask import Blueprint, request, render_template, redirect, url_for
from flask_login import login_user, login_required, logout_user, UserMixin

from app.controllers.insights import process_query

routes = Blueprint('routes', __name__)

@routes.route('/')
def login():
    return render_template('login.html')

@routes.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@routes.route('/ask', methods=['POST'])
@login_required
def ask():
    question = request.form['question']
    answer = process_query(question)
    return render_template('result.html', question=question, answer=answer)

@routes.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))
